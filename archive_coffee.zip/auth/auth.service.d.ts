import { User } from '../Models/user.schema';
import { JwtService } from '@nestjs/jwt';
import { UserService } from '../users/users.service';
export declare class AuthService {
    private jwtService;
    private userService;
    constructor(jwtService: JwtService, userService: UserService);
    validateUser(email: string, pass: string): Promise<any>;
    login(user: User): Promise<any>;
    addPrivilege(user: any, priviledgesToAdd: string[]): Promise<any>;
}
