import { Schema } from 'mongoose';
import { Role } from '../auth/role.enum';
export declare const UserSchema: Schema<import("mongoose").Document<any>, import("mongoose").Model<import("mongoose").Document<any>>, undefined>;
export interface User {
    _id: string;
    email: string;
    name: string;
    organization: string;
    password: string;
    roles: Role[];
}
