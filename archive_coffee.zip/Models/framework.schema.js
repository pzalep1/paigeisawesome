"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FrameworkSchema = void 0;
const mongoose_1 = require("mongoose");
exports.FrameworkSchema = new mongoose_1.Schema({
    _id: mongoose_1.Types.ObjectId,
    name: String,
    year: String,
    author: String,
    status: String,
    levels: [String],
}, {
    collection: 'frameworks'
});
exports.FrameworkSchema.index({ '$**': 'text' });
//# sourceMappingURL=framework.schema.js.map