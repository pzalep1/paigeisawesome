import { User } from 'src/Models/user.schema';
import { UserService } from './users.service';
import { AuthService } from '../auth/auth.service';
import { UserWriteDTO } from '../DTO/userWriteDTO';
export declare class UserController {
    private readonly userService;
    private readonly authService;
    constructor(userService: UserService, authService: AuthService);
    register(user: UserWriteDTO): Promise<string>;
    login(user: any): Promise<any>;
    getAllUsers(): Promise<User[]>;
    getUser(userId: string): Promise<any>;
    verifyToken(req: any): Promise<any>;
    addPrivilege(req: any, privilegesToAdd: string[]): Promise<string>;
}
