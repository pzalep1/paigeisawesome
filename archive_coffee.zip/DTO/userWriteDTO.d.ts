export declare class UserWriteDTO {
    email: string;
    password: string;
    organization: string;
    name: string;
}
