"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Roles = exports.ROLES_KEY = void 0;
const common_1 = require("@nestjs/common");
var role_enum_1 = require("./role.enum");
Object.defineProperty(exports, "Role", { enumerable: true, get: function () { return role_enum_1.Role; } });
exports.ROLES_KEY = 'roles';
exports.Roles = (...roles) => common_1.SetMetadata(exports.ROLES_KEY, roles);
//# sourceMappingURL=roles.decorator.js.map