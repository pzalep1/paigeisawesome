export declare class GuidelineWriteDTO {
    name: string;
    guidelineText: string;
}
