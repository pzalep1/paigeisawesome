"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserSchema = void 0;
const mongoose_1 = require("mongoose");
exports.UserSchema = new mongoose_1.Schema({
    _id: mongoose_1.Types.ObjectId,
    email: String,
    password: String,
    organization: String,
    name: String,
    roles: [String],
}, {
    collection: 'users'
});
//# sourceMappingURL=user.schema.js.map