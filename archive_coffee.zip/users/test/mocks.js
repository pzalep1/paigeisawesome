"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.unregisteredUser = exports.invalidUserLogin = exports.validUserLogin = exports.validUser = exports.missingOrg = exports.missingName = exports.missingPassword = exports.missingEmail = exports.fakeAdmin = exports.fakeUser2 = exports.fakeUser = exports.mockedJwtService = void 0;
exports.mockedJwtService = {
    sign: () => ''
};
exports.fakeUser = {
    "email": "carcher@enterprise.gov",
    "name": "Captain Archer",
    "organization": "University of Awesome Sauce",
    "password": "IlikegreeneggsAndHam$$Money",
    "roles": []
};
exports.fakeUser2 = {
    "email": "pzalep1@students.towson.edu",
    "name": "Paige Zaleppa",
    "organization": "University of Awesome Sauce",
    "password": "wowIcanreallydancetotheyear3000",
    "roles": []
};
exports.fakeAdmin = {
    "email": "swagCurriculum@swaglearning.team",
    "name": "Cardi B",
    "organization": "Swag Curriculum",
    "password": "realestAdmin$999",
    "roles": ["admin"]
};
exports.missingEmail = {
    "name": "Cardi B",
    "organization": "Swag Curriculum",
    "password": "realestAdmin#44"
};
exports.missingPassword = {
    "name": "Cardi B",
    "organization": "Swag Curriculum",
    "email": "swagcurriculum@swaglearning.com"
};
exports.missingName = {
    "email": "swagCurriculum@swaglearning.team",
    "organization": "Swag Curriculum",
    "password": "realestAdmin#22"
};
exports.missingOrg = {
    "email": "swagCurriculum@swaglearning.team",
    "name": "Cardi B",
    "password": "realestAdmin#22"
};
exports.validUser = {
    "email": "swagCurriculum@swaglearning.com",
    "name": "Cardi Bacardi",
    "organization": "Swag Curriculum",
    "password": "realestAdmin$999",
};
exports.validUserLogin = {
    "email": "swagCurriculum@swaglearning.com",
    "password": "realestAdmin$999"
};
exports.invalidUserLogin = {
    "email": "swagCurriculum@swaglearning.com",
    "password": "password"
};
exports.unregisteredUser = {
    "email": "iamafraud@fake.com",
    "password": "Iamfake"
};
//# sourceMappingURL=mocks.js.map