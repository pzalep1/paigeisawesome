import { Schema } from 'mongoose';
export declare const GuidelineSchema: Schema<import("mongoose").Document<any>, import("mongoose").Model<import("mongoose").Document<any>>, undefined>;
export interface Guideline {
    _id: string;
    frameworkName: string;
    year: string;
    author: string;
    name: string;
    guidelineText: string;
}
