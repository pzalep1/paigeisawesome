import { Schema } from 'mongoose';
export declare const FrameworkSchema: Schema<import("mongoose").Document<any>, import("mongoose").Model<import("mongoose").Document<any>>, undefined>;
export interface Framework {
    _id: string;
    name: string;
    year: string;
    author: string;
    status: string;
    levels: string[];
    guidelines: string[];
}
