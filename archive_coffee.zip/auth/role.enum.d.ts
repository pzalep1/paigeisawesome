export declare enum Role {
    User = "User",
    Admin = "Admin",
    Curator = "Curator"
}
