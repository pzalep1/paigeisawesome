"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FrameworkService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongoose_2 = require("mongoose");
const frameworkDTO_1 = require("../DTO/frameworkDTO");
const framework_schema_1 = require("../Models/framework.schema");
const guideline_schema_1 = require("../Models/guideline.schema");
let FrameworkService = class FrameworkService {
    constructor(frameworkModel, guidelineModel) {
        this.frameworkModel = frameworkModel;
        this.guidelineModel = guidelineModel;
    }
    async createFramework(args) {
        await this.validateFrameworkUpdates({ frameworkUpdates: args.framework });
        const framework = new this.frameworkModel(Object.assign(Object.assign({}, args.framework), { status: 'unreleased', _id: new mongoose_2.Types.ObjectId() }));
        await framework.save();
        return framework._id;
    }
    async updateFramework(args) {
        await this.validateFrameworkUpdates(args);
        const updated = await this.frameworkModel.updateOne({ _id: new mongoose_2.Types.ObjectId(args.frameworkId) }, { $set: Object.assign(Object.assign({}, args.frameworkUpdates), { lastUpdated: Date.now() }) });
        if (updated.nModified > 0) {
            const guidelines = await this.getGuidelinesForFramework({ frameworkId: args.frameworkId });
            for (const guideline of guidelines) {
                await this.updateGuideline({ frameworkId: args.frameworkId, guidelineId: guideline._id, guideline });
            }
        }
        else {
            throw new common_1.HttpException('Could not update framework!', common_1.HttpStatus.BAD_REQUEST);
        }
    }
    async getFrameworks(args) {
        const aggregation = [];
        if (args.query.text) {
            aggregation.push({ $match: { $text: { $search: args.query.text } } }, { $sort: { score: { $meta: 'textScore' } } });
        }
        if (args.query.year) {
            aggregation.push({ $match: { year: args.query.year } });
        }
        if (args.query.status) {
            aggregation.push({ $match: { status: args.query.status } });
        }
        if (args.query.level) {
            args.query.level = [args.query.level];
            aggregation.push({ $match: { levels: { $in: args.query.level } } });
        }
        if (aggregation.length > 0) {
            return await this.frameworkModel.aggregate(aggregation).exec();
        }
        else {
            return await this.frameworkModel.find().exec();
        }
    }
    async getSingleFramework(args) {
        const framework = await this.frameworkModel.findOne({ _id: args.frameworkId });
        if (framework) {
            return framework;
        }
        else {
            throw new common_1.HttpException('Framework not found!', common_1.HttpStatus.NOT_FOUND);
        }
    }
    async createGuideline(args) {
        const framework = await this.getSingleFramework({ frameworkId: args.frameworkId });
        const guideline = new this.guidelineModel(Object.assign(Object.assign({ frameworkId: args.frameworkId, status: 'unreleased', year: framework.year, author: framework.author, levels: framework.levels }, args.guideline), { _id: new mongoose_2.Types.ObjectId() }));
        await guideline.save();
        return guideline._id;
    }
    async updateGuideline(args) {
        await this.validateGuidelineUpdate(args);
        let update = args.guideline;
        const framework = await this.getSingleFramework({ frameworkId: args.frameworkId });
        if (args.guideline._doc && (framework.status !== args.guideline._doc.status)) {
            args.guideline._doc.status = framework.status;
            update = args.guideline._doc;
        }
        await this.guidelineModel.updateOne({ _id: new mongoose_2.Types.ObjectId(args.guidelineId) }, { $set: Object.assign(Object.assign({}, update), { lastUpdated: Date.now() }) }).exec();
    }
    async deleteGuideline(args) {
        await this.guidelineModel.deleteOne({ _id: new mongoose_2.Types.ObjectId(args.guidelineId) }).exec();
        ;
    }
    async getSingleGuideline(args) {
        const guideline = await this.guidelineModel.findOne({ _id: new mongoose_2.Types.ObjectId(args.guidelineId) }).exec();
        if (guideline) {
            return guideline;
        }
        else {
            throw new common_1.HttpException('Guideline not found!', common_1.HttpStatus.NOT_FOUND);
        }
    }
    async getGuidelinesForFramework(args) {
        return await this.guidelineModel.find({ frameworkId: args.frameworkId }).exec();
    }
    async getAllGuidelines(args) {
        const aggregation = [];
        if (args.query.text) {
            aggregation.push({ $match: { $text: { $search: args.query.text } } }, { $sort: { score: { $meta: 'textScore' } } });
        }
        if (args.query.year) {
            aggregation.push({ $match: { year: args.query.year } });
        }
        if (args.query.status) {
            aggregation.push({ $match: { status: args.query.status } });
        }
        if (args.query.level) {
            args.query.level = [args.query.level];
            aggregation.push({ $match: { levels: { $in: args.query.level } } });
        }
        if (aggregation.length > 0) {
            return await this.guidelineModel.aggregate(aggregation).exec();
        }
        else {
            return await this.guidelineModel.find().exec();
        }
    }
    async validateFrameworkUpdates(args) {
        let framework = undefined;
        if (args.frameworkId) {
            framework = await this.getSingleFramework({ frameworkId: args.frameworkId });
        }
        else {
            framework = {};
        }
        if (framework) {
            const updates = args.frameworkUpdates;
            if (updates.status && (updates.status !== 'unreleased' && updates.status !== 'released')) {
                throw new common_1.HttpException('Framework moving to invalid status', common_1.HttpStatus.BAD_REQUEST);
            }
            if (updates.year && (Number(updates.year) < 1998 || Number(updates.year) > 2030)) {
                throw new common_1.HttpException('Framework must have a year between 1998 and 2030', common_1.HttpStatus.BAD_REQUEST);
            }
        }
        else {
            throw new common_1.HttpException('Framework not found!', common_1.HttpStatus.NOT_FOUND);
        }
    }
    async validateGuidelineUpdate(args) {
        const framework = await this.getSingleFramework({ frameworkId: args.frameworkId });
        if (framework) {
            const guideline = await this.getSingleGuideline({ frameworkId: args.frameworkId, guidelineId: args.guidelineId });
            if (guideline) {
                const updates = args.guideline;
                if (updates.status && (updates.status !== 'unreleased' && updates.status !== 'released')) {
                    throw new common_1.HttpException('Guideline moving to invalid status', common_1.HttpStatus.BAD_REQUEST);
                }
                if (updates.year && (Number(updates.year) < 1998 || Number(updates.year) > 2030)) {
                    throw new common_1.HttpException('Guideline must have a year between 1998 and 2030', common_1.HttpStatus.BAD_REQUEST);
                }
            }
        }
        else {
            throw new common_1.HttpException('Framework not found!', common_1.HttpStatus.NOT_FOUND);
        }
    }
};
FrameworkService = __decorate([
    common_1.Injectable(),
    __param(0, mongoose_1.InjectModel('Framework')), __param(1, mongoose_1.InjectModel('Guideline')),
    __metadata("design:paramtypes", [mongoose_2.Model, mongoose_2.Model])
], FrameworkService);
exports.FrameworkService = FrameworkService;
//# sourceMappingURL=frameworks.service.js.map