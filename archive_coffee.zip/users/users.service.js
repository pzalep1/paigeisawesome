"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const common_1 = require("@nestjs/common");
const mongoose_1 = require("mongoose");
const auth_service_1 = require("../auth/auth.service");
const bcrypt = require("bcrypt");
const mongoose_2 = require("@nestjs/mongoose");
let UserService = class UserService {
    constructor(userModel, authService) {
        this.userModel = userModel;
        this.authService = authService;
    }
    async register(user) {
        if (user &&
            user.email !== undefined &&
            user.password !== undefined &&
            user.organization !== undefined &&
            user.name !== undefined) {
            const email = user.email;
            const found = await this.userModel.findOne({ email }).exec();
            if (!found) {
                const saltRounds = 10;
                const password = user.password;
                const hash = await bcrypt.hash(password, saltRounds);
                user.password = hash;
                const userDoc = new this.userModel(Object.assign(Object.assign({}, user), { _id: new mongoose_1.Types.ObjectId() }));
                await userDoc.save();
            }
            else {
                throw new common_1.HttpException('Email already in use!', common_1.HttpStatus.CONFLICT);
            }
        }
        else {
            throw new common_1.HttpException('Body must contain email, password, organization, and name', common_1.HttpStatus.BAD_REQUEST);
        }
    }
    async getUsers() {
        return this.userModel.find().exec();
    }
    async getSingleUser(email) {
        return this.userModel.findOne({ email }).exec();
    }
    async getUserById(id) {
        return this.userModel.findOne({ _id: id }).select("-password").exec();
    }
    async updateSingleUser(email, roles) {
        await this.userModel.updateOne({ email }, { roles }).exec();
    }
};
UserService = __decorate([
    common_1.Injectable(),
    __param(0, mongoose_2.InjectModel('User')),
    __param(1, common_1.Inject(common_1.forwardRef(() => auth_service_1.AuthService))),
    __metadata("design:paramtypes", [mongoose_1.Model,
        auth_service_1.AuthService])
], UserService);
exports.UserService = UserService;
//# sourceMappingURL=users.service.js.map