"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FrameworkController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const frameworkDTO_1 = require("../DTO/frameworkDTO");
const guidelineDTO_1 = require("../DTO/guidelineDTO");
const frameworks_service_1 = require("./frameworks.service");
let FrameworkController = class FrameworkController {
    constructor(frameworkService) {
        this.frameworkService = frameworkService;
    }
    async createFramework(framework) {
        return this.frameworkService.createFramework({
            framework: framework
        });
    }
    async updateFramework(frameworkId, frameworkUpdates) {
        return this.frameworkService.updateFramework({
            frameworkId: frameworkId,
            frameworkUpdates: frameworkUpdates
        });
    }
    async getFrameworks(query) {
        return this.frameworkService.getFrameworks({
            query: query
        });
    }
    async getSingleFramework(frameworkId) {
        return this.frameworkService.getSingleFramework({
            frameworkId: frameworkId
        });
    }
    async createGuideline(frameworkId, guideline) {
        return this.frameworkService.createGuideline({
            frameworkId: frameworkId,
            guideline: guideline
        });
    }
    async updateGuideline(frameworkId, guidelineId, guideline) {
        return this.frameworkService.updateGuideline({
            frameworkId: frameworkId,
            guidelineId: guidelineId,
            guideline: guideline
        });
    }
    async deleteGuideline(frameworkId, guidelineId) {
        return this.frameworkService.deleteGuideline({
            frameworkId: frameworkId,
            guidelineId: guidelineId
        });
    }
    async getSingleGuideline(frameworkId, guidelineId) {
        return this.frameworkService.getSingleGuideline({
            frameworkId: frameworkId,
            guidelineId: guidelineId
        });
    }
    async getGuidelinesForFramework(frameworkId) {
        return this.frameworkService.getGuidelinesForFramework({
            frameworkId: frameworkId,
        });
    }
    async getAllGuidelines(query) {
        return this.frameworkService.getAllGuidelines({
            query: query,
        });
    }
};
__decorate([
    common_1.Post('/frameworks'),
    swagger_1.ApiOkResponse({ description: 'Framework Created!' }),
    swagger_1.ApiBadRequestResponse({ description: 'Invalid name, year, or author for framework' }),
    swagger_1.ApiBody({ description: 'Body for a framework', type: frameworkDTO_1.FrameworkWriteDTO }),
    common_1.UsePipes(new common_1.ValidationPipe({ transform: true })),
    __param(0, common_1.Body('framework')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [frameworkDTO_1.FrameworkWriteDTO]),
    __metadata("design:returntype", Promise)
], FrameworkController.prototype, "createFramework", null);
__decorate([
    common_1.Patch('/frameworks/:frameworkId'),
    swagger_1.ApiOkResponse({ description: 'Framework Updated!' }),
    swagger_1.ApiBadRequestResponse({ description: 'Invalid updates for framework' }),
    swagger_1.ApiForbiddenResponse({ description: 'You are not permitted to update frameworks.' }),
    swagger_1.ApiNotFoundResponse({ description: 'The specified framework was not found.' }),
    swagger_1.ApiBody({ description: 'Body for a partial framework', type: frameworkDTO_1.FrameworkWriteDTO }),
    common_1.UsePipes(new common_1.ValidationPipe({ transform: true })),
    __param(0, common_1.Param('frameworkId')),
    __param(1, common_1.Body('framework')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], FrameworkController.prototype, "updateFramework", null);
__decorate([
    common_1.Get('/frameworks'),
    swagger_1.ApiOkResponse({ description: 'OK.' }),
    swagger_1.ApiBadRequestResponse({ description: 'Framework query invalid' }),
    __param(0, common_1.Query()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], FrameworkController.prototype, "getFrameworks", null);
__decorate([
    common_1.Get('/frameworks/:frameworkId'),
    swagger_1.ApiOkResponse({ description: 'OK.' }),
    swagger_1.ApiBadRequestResponse({ description: 'The specified ID is not valid' }),
    swagger_1.ApiForbiddenResponse({ description: 'You do not have access to the given framework' }),
    swagger_1.ApiNotFoundResponse({ description: 'The specified framework was not found' }),
    __param(0, common_1.Param('frameworkId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], FrameworkController.prototype, "getSingleFramework", null);
__decorate([
    common_1.Post('/frameworks/:frameworkId/guidelines'),
    swagger_1.ApiOkResponse({ description: 'Guideline created!' }),
    swagger_1.ApiBadRequestResponse({ description: 'Guideline is not in the correct format' }),
    swagger_1.ApiForbiddenResponse({ description: 'You do not have permission to create a guideline' }),
    swagger_1.ApiNotFoundResponse({ description: 'The specified framework does not exist' }),
    swagger_1.ApiBody({ description: 'Body for a Guideline', type: guidelineDTO_1.GuidelineWriteDTO }),
    common_1.UsePipes(new common_1.ValidationPipe({ transform: true })),
    __param(0, common_1.Param('frameworkId')),
    __param(1, common_1.Body('guideline')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, guidelineDTO_1.GuidelineWriteDTO]),
    __metadata("design:returntype", Promise)
], FrameworkController.prototype, "createGuideline", null);
__decorate([
    common_1.Patch('/frameworks/:frameworkId/guidelines/:guidelineId'),
    swagger_1.ApiOkResponse({ description: 'OK.' }),
    swagger_1.ApiBadRequestResponse({ description: 'Guideline is not in correct format' }),
    swagger_1.ApiForbiddenResponse({ description: 'You do not have permission to update this guideline' }),
    swagger_1.ApiNotFoundResponse({ description: 'The specified framework or guideline does not exist' }),
    swagger_1.ApiBody({ description: 'Body for a Guideline', type: guidelineDTO_1.GuidelineWriteDTO }),
    common_1.UsePipes(new common_1.ValidationPipe({ transform: true })),
    __param(0, common_1.Param('frameworkId')),
    __param(1, common_1.Param('guidelineId')),
    __param(2, common_1.Body('guideline')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, Object]),
    __metadata("design:returntype", Promise)
], FrameworkController.prototype, "updateGuideline", null);
__decorate([
    common_1.Delete('/frameworks/:frameworkId/guidelines/:guidelineId'),
    swagger_1.ApiOkResponse({ description: 'Deleted successfully.' }),
    swagger_1.ApiBadRequestResponse({ description: 'Mongo id is not valid' }),
    swagger_1.ApiForbiddenResponse({ description: 'You are not authorized to delete this guideline.' }),
    swagger_1.ApiNotFoundResponse({ description: 'The specified guideline could not be found' }),
    __param(0, common_1.Param('frameworkId')),
    __param(1, common_1.Param('guidelineId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], FrameworkController.prototype, "deleteGuideline", null);
__decorate([
    common_1.Get('/frameworks/:framework/guidelines/:guidelineId'),
    swagger_1.ApiOkResponse({ description: 'OK.' }),
    swagger_1.ApiBadRequestResponse({ description: 'FrameworkId or guidelineId is not valid' }),
    swagger_1.ApiForbiddenResponse({ description: 'You are not authorized to see this guideline' }),
    swagger_1.ApiNotFoundResponse({ description: 'The specified guideline could not be found' }),
    __param(0, common_1.Param('frameworkId')),
    __param(1, common_1.Param('guidelineId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], FrameworkController.prototype, "getSingleGuideline", null);
__decorate([
    common_1.Get('/frameworks/:frameworkId/guidelines'),
    swagger_1.ApiOkResponse({ description: 'Welcome to the coffee-service API' }),
    swagger_1.ApiBadRequestResponse({ description: 'The frameworkId is not valid' }),
    swagger_1.ApiForbiddenResponse({ description: 'You are not authorized to view the guidelines for the framework' }),
    swagger_1.ApiNotFoundResponse({ description: 'The given framework was not found' }),
    __param(0, common_1.Param('frameworkId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], FrameworkController.prototype, "getGuidelinesForFramework", null);
__decorate([
    common_1.Get('/guidelines'),
    swagger_1.ApiOkResponse({ description: 'Everything is A ok' }),
    swagger_1.ApiBadRequestResponse({ description: 'The query is not valid.' }),
    __param(0, common_1.Query()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], FrameworkController.prototype, "getAllGuidelines", null);
FrameworkController = __decorate([
    swagger_1.ApiTags('frameworks'),
    common_1.Controller(),
    __metadata("design:paramtypes", [frameworks_service_1.FrameworkService])
], FrameworkController);
exports.FrameworkController = FrameworkController;
//# sourceMappingURL=frameworks.controller.js.map