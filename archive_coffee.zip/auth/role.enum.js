"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Role = void 0;
var Role;
(function (Role) {
    Role["User"] = "User";
    Role["Admin"] = "Admin";
    Role["Curator"] = "Curator";
})(Role = exports.Role || (exports.Role = {}));
//# sourceMappingURL=role.enum.js.map