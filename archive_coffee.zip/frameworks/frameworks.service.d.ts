import { Model } from 'mongoose';
import { FrameworkWriteDTO } from 'src/DTO/frameworkDTO';
import { Framework } from 'src/Models/framework.schema';
import { Guideline } from 'src/Models/guideline.schema';
export declare class FrameworkService {
    private frameworkModel;
    private guidelineModel;
    constructor(frameworkModel: Model<any>, guidelineModel: Model<any>);
    createFramework(args: {
        framework: FrameworkWriteDTO;
    }): Promise<string>;
    updateFramework(args: {
        frameworkId: string;
        frameworkUpdates: any;
    }): Promise<void>;
    getFrameworks(args: {
        query: any;
    }): Promise<Framework[]>;
    getSingleFramework(args: {
        frameworkId: string;
    }): Promise<Framework>;
    createGuideline(args: {
        frameworkId: string;
        guideline: any;
    }): Promise<string>;
    updateGuideline(args: {
        frameworkId: string;
        guidelineId: string;
        guideline: any;
    }): Promise<void>;
    deleteGuideline(args: {
        frameworkId: string;
        guidelineId: string;
    }): Promise<void>;
    getSingleGuideline(args: {
        frameworkId: string;
        guidelineId: string;
    }): Promise<Guideline>;
    getGuidelinesForFramework(args: {
        frameworkId: string;
    }): Promise<Guideline[]>;
    getAllGuidelines(args: {
        query: any;
    }): Promise<Guideline[]>;
    validateFrameworkUpdates(args: any): Promise<void>;
    validateGuidelineUpdate(args: any): Promise<void>;
}
