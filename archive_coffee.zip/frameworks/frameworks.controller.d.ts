import { FrameworkWriteDTO } from '../DTO/frameworkDTO';
import { GuidelineWriteDTO } from '../DTO/guidelineDTO';
import { Framework } from '../Models/framework.schema';
import { Guideline } from '../Models/guideline.schema';
import { FrameworkService } from './frameworks.service';
export declare class FrameworkController {
    private readonly frameworkService;
    constructor(frameworkService: FrameworkService);
    createFramework(framework: FrameworkWriteDTO): Promise<string>;
    updateFramework(frameworkId: string, frameworkUpdates: Partial<Framework>): Promise<void>;
    getFrameworks(query: any): Promise<Framework[]>;
    getSingleFramework(frameworkId: string): Promise<Framework>;
    createGuideline(frameworkId: string, guideline: GuidelineWriteDTO): Promise<string>;
    updateGuideline(frameworkId: string, guidelineId: string, guideline: any): Promise<void>;
    deleteGuideline(frameworkId: string, guidelineId: string): Promise<void>;
    getSingleGuideline(frameworkId: string, guidelineId: string): Promise<Guideline>;
    getGuidelinesForFramework(frameworkId: string): Promise<Guideline[]>;
    getAllGuidelines(query: any): Promise<Guideline[]>;
}
