"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GuidelineSchema = void 0;
const mongoose_1 = require("mongoose");
exports.GuidelineSchema = new mongoose_1.Schema({
    _id: mongoose_1.Types.ObjectId,
    frameworkId: String,
    name: String,
    guidelineText: String,
    status: String,
    year: String,
    author: String,
    levels: [String],
}, {
    collection: 'guidelines'
});
exports.GuidelineSchema.index({ '$**': 'text' });
//# sourceMappingURL=guideline.schema.js.map