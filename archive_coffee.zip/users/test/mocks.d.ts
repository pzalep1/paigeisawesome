export declare const mockedJwtService: {
    sign: () => string;
};
export declare const fakeUser: {
    email: string;
    name: string;
    organization: string;
    password: string;
    roles: any[];
};
export declare const fakeUser2: {
    email: string;
    name: string;
    organization: string;
    password: string;
    roles: any[];
};
export declare const fakeAdmin: {
    email: string;
    name: string;
    organization: string;
    password: string;
    roles: string[];
};
export declare const missingEmail: {
    name: string;
    organization: string;
    password: string;
};
export declare const missingPassword: {
    name: string;
    organization: string;
    email: string;
};
export declare const missingName: {
    email: string;
    organization: string;
    password: string;
};
export declare const missingOrg: {
    email: string;
    name: string;
    password: string;
};
export declare const validUser: {
    email: string;
    name: string;
    organization: string;
    password: string;
};
export declare const validUserLogin: {
    email: string;
    password: string;
};
export declare const invalidUserLogin: {
    email: string;
    password: string;
};
export declare const unregisteredUser: {
    email: string;
    password: string;
};
