export declare class FrameworkWriteDTO {
    name: string;
    author: string;
    year: string;
    levels: string[];
}
