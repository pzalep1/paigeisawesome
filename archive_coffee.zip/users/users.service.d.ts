import { Model } from 'mongoose';
import { AuthService } from '../auth/auth.service';
import { User } from '../Models/user.schema';
import { UserWriteDTO } from '../DTO/userWriteDTO';
export declare class UserService {
    private userModel;
    private authService;
    constructor(userModel: Model<any>, authService: AuthService);
    register(user: UserWriteDTO): Promise<any>;
    getUsers(): Promise<User[]>;
    getSingleUser(email: string): Promise<User>;
    getUserById(id: string): Promise<User>;
    updateSingleUser(email: string, roles: string[]): Promise<void>;
}
