export declare class FrameworkModule {
}
