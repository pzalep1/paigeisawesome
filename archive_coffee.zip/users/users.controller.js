"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const swagger_1 = require("@nestjs/swagger");
const common_1 = require("@nestjs/common");
const user_schema_1 = require("../Models/user.schema");
const users_service_1 = require("./users.service");
const jwt_auth_guard_1 = require("../auth/jwt-auth.guard");
const auth_service_1 = require("../auth/auth.service");
const roles_decorator_1 = require("../auth/roles.decorator");
const roles_guard_1 = require("../auth/roles.guard");
const userWriteDTO_1 = require("../DTO/userWriteDTO");
let UserController = class UserController {
    constructor(userService, authService) {
        this.userService = userService;
        this.authService = authService;
    }
    async register(user) {
        const token = await this.userService.register(user);
        return token;
    }
    async login(user) {
        return await this.authService.login(user);
    }
    async getAllUsers() {
        const users = await this.userService.getUsers();
        return users;
    }
    async getUser(userId) {
        let userValid = await this.userService.getUserById(userId);
        return { _id: userValid._id, name: userValid.name, email: userValid.email, roles: userValid.roles, organization: userValid.organization };
    }
    async verifyToken(req) {
        return req.user;
    }
    async addPrivilege(req, privilegesToAdd) {
        return await this.authService.addPrivilege(req.user, privilegesToAdd);
    }
};
__decorate([
    common_1.Post('/users'),
    swagger_1.ApiOperation({ summary: 'Register User' }),
    swagger_1.ApiOkResponse({ description: 'Welcome to the coffee-service API' }),
    swagger_1.ApiBadRequestResponse({ description: 'Swagger not working right' }),
    swagger_1.ApiForbiddenResponse({ description: '' }),
    swagger_1.ApiNotFoundResponse({ description: '' }),
    swagger_1.ApiBody({ description: 'User Registration', type: userWriteDTO_1.UserWriteDTO }),
    common_1.UsePipes(new common_1.ValidationPipe({ transform: true })),
    __param(0, common_1.Body('user')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [userWriteDTO_1.UserWriteDTO]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "register", null);
__decorate([
    common_1.Post('/users/tokens'),
    swagger_1.ApiOperation({ summary: 'Login' }),
    swagger_1.ApiOkResponse({ description: 'Welcome to the coffee-service API' }),
    swagger_1.ApiBadRequestResponse({ description: 'Swagger not working right' }),
    swagger_1.ApiForbiddenResponse({ description: 'User Login' }),
    swagger_1.ApiNotFoundResponse({ description: '' }),
    swagger_1.ApiBody({}),
    __param(0, common_1.Body('user')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "login", null);
__decorate([
    common_1.Get('/users'),
    swagger_1.ApiOperation({ summary: 'List all User Resources' }),
    swagger_1.ApiOkResponse({ description: 'Welcome to the coffee-service API' }),
    swagger_1.ApiBadRequestResponse({ description: 'Swagger not working right' }),
    swagger_1.ApiForbiddenResponse({ description: '' }),
    swagger_1.ApiNotFoundResponse({ description: '' }),
    swagger_1.ApiBody({}),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], UserController.prototype, "getAllUsers", null);
__decorate([
    common_1.UseGuards(jwt_auth_guard_1.JwtAuthGuard),
    common_1.Get('/users/:userId'),
    swagger_1.ApiOkResponse({ description: 'Welcome to the coffee-service API' }),
    swagger_1.ApiBadRequestResponse({ description: 'Swagger not working right' }),
    swagger_1.ApiForbiddenResponse({ description: '' }),
    swagger_1.ApiNotFoundResponse({ description: '' }),
    swagger_1.ApiBody({}),
    __param(0, common_1.Param('userId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "getUser", null);
__decorate([
    common_1.UseGuards(jwt_auth_guard_1.JwtAuthGuard),
    common_1.Get('users/tokens'),
    swagger_1.ApiOperation({ summary: 'Not sure what this does...' }),
    swagger_1.ApiOkResponse({ description: 'Welcome to the coffee-service API' }),
    swagger_1.ApiBadRequestResponse({ description: 'Swagger not working right' }),
    swagger_1.ApiForbiddenResponse({ description: '' }),
    swagger_1.ApiNotFoundResponse({ description: '' }),
    swagger_1.ApiBody({}),
    __param(0, common_1.Request()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "verifyToken", null);
__decorate([
    roles_decorator_1.Roles(roles_decorator_1.Role.Admin),
    common_1.UseGuards(roles_guard_1.RolesGuard),
    common_1.UseGuards(jwt_auth_guard_1.JwtAuthGuard),
    common_1.Post('/users/:userId/privileges'),
    swagger_1.ApiOperation({ summary: 'Admin can add a privilege to a user' }),
    swagger_1.ApiOkResponse({ description: 'Welcome to the coffee-service API' }),
    swagger_1.ApiBadRequestResponse({ description: 'Swagger not working right' }),
    swagger_1.ApiForbiddenResponse({ description: '' }),
    swagger_1.ApiNotFoundResponse({ description: '' }),
    swagger_1.ApiBody({ description: 'Add various privileges to user' }),
    __param(0, common_1.Req()),
    __param(1, common_1.Body('privileges')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Array]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "addPrivilege", null);
UserController = __decorate([
    swagger_1.ApiTags('users'),
    common_1.Controller(),
    __metadata("design:paramtypes", [users_service_1.UserService,
        auth_service_1.AuthService])
], UserController);
exports.UserController = UserController;
//# sourceMappingURL=users.controller.js.map